/*
 FPS Constructor - Weapons
 Copyright© Dastardly Banana Productions 2011-2012
 This script, and all others contained within the Dastardly Banana Weapons Package are licensed under the terms of the
 Unity Asset Store End User License Agreement at http://download.unity3d.com/assetstore/customer-eula.pdf 
 
 For additional information contact us info@dastardlybanana.com.
*/

var tempNamesArray = new Array("Ammo Set 1", "Ammo Set 2", "Ammo Set 3", "Ammo Set 4", "Ammo Set 5", "Ammo Set 6", "Ammo Set 7",
"Ammo Set 8", "Ammo Set 9", "Ammo Set 10");
var namesArray = new String[10];
var clipsArray = new int[10];
var maxClipsArray = new int[10];
var infiniteArray = new boolean[10];