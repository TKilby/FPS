#pragma strict
@HideInInspector 
var up : boolean; //GetButtonUp
@HideInInspector 
var down : boolean; //GetButtonDown
@HideInInspector 
var got : boolean; //GetButton
@HideInInspector 
var axis : float; //GetAxis

var id : String; //identifier for this input